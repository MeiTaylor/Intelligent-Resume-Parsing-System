<template>
    <div class="home" style="background-color: #F0F2F5;height: 700px;">
        <div style="height:10px">
        </div>
        <el-row :gutter="10">
            <el-col :span="14" :offset="5">
                <ElCard>
                    <el-row style="margin-top: 10px;">
                        <span>岗位名称: </span>
                        <ElInput></ElInput>
                    </el-row>

                    <el-row style="margin-top: 10px;">
                        <span>岗位信息: </span>
                        <ElInput></ElInput>
                    </el-row>

                    <el-row style="margin-top: 10px;">
                        <span>最低工作年限: </span>
                        <ElInput></ElInput>
                    </el-row>
                    <el-row style="margin-top: 10px;">
                        <span>最低学历: </span>
                        <ElInput></ElInput>
                    </el-row>
                    <el-row style="margin-top: 10px;">
                        <ElButton type="primary" @click="onSubmit"> 保存修改 </ElButton>
                    </el-row>

                </ElCard>
            </el-col>
        </el-row>
    </div>
</template>
<script>
export default {
    data() {
    },
    method: {},
}
</script>
    
    
    